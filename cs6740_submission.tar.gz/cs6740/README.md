This repo is for the projects assigned in cs 6740.


